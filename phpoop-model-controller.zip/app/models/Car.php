<?php 

namespace App\Models;

use Core\Model\Model;

class Car extends Model{
    
}