<?php
namespace App\Controller;

use App\Models\Car;

class CarController{
    
    public function index(){

        /* get all */
        //$model = Car::all();
        // dump($model);

        /* add new */
        // $model = new Car();
        // $model->mark = 'Niva';
        // $model->model = '4x4';
        // $model->speed = '16';
        // $model->year= '2015';
        // $model->save();
        // dump($model);

        /* find by id*/
        $model = Car::find(8);

        /* save update data if find result*/     
        // $model->mark = 'Chevrolet';
        // $model->model = 'Camaro';
        // $model->speed = '250';
        // $model->year= '2015';
        // $model->save();
        dump($model);
        // dump($model->toArray());

        //dump($model->toJson());
    }

}