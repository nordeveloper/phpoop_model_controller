<?php

use App\Controller\CarController;

require __DIR__."/core/bootstarp.php";

$controller = new CarController();

$controller->index();