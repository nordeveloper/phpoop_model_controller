<?php

error_reporting(E_ALL);

define('DBCONFIG',[
    'host'=>'localhost',
    'dbuser'=>'root',
    'dbpass'=>'',
    'dbname'=>'phpoop-dbmodel'
]);

require __DIR__.'/../vendor/autoload.php';
