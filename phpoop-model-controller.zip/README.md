<p>Example php oop db singltone, model (all, find, save) extend DataBase insert, update, query</p>

<p>for db import phpexamples.sql</p>

<p>Author Norayr Petrosyan https://www.facebook.com/nordeveloper</p>